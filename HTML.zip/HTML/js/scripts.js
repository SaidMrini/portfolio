/* Toggle between showing and hiding the navigation menu links when the user clicks on the hamburger menu / bar icon */
function myFunction() {
  var x = document.getElementById("myLinks");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}

var links = document.getElementsByClassName('link');
for(var i = 0; i <= links.length; i++)
   addClass(i);


function addClass(id){
   setTimeout(function(){
      if(id > 0) links[id-1].classList.remove('hover');
      links[id].classList.add('hover');
   }, id*750) ;
}